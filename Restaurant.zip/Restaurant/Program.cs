﻿using System.Globalization;

class MenuItem
{
    public string Name { get; set; }
    public string Description { get; set; }
    public double Price { get; set; }
    public int Quantity { get; set; }

    public MenuItem(string name, string description, double price, int quantity)
    {
        Name = name;
        Description = description;
        Price = price;
        Quantity = quantity;
    }
}
class Order
{
    public List<MenuItem> Items { get; set; }
    public decimal Total { get; set; }
    public string Date { get; set; }

    public Order(List<MenuItem> items, string date)
    {
        Items = items;
        Date = date;
        Total = (decimal)items.Sum(i => i.Price);
    }
}
class RestaurantMenu
{
    static List<MenuItem> menu = new List<MenuItem>();
    static List<MenuItem> order = new List<MenuItem>();
    static List<Order> orderHistory = new List<Order>();

    static void ViewHistory()
    {
        if (orderHistory.Count == 0)
        {
            Console.WriteLine("Brak historii zamówień do wyświetlenia");
            return;
        }

        foreach (var order in orderHistory)
        {
            Console.WriteLine("Items: " + order.Items);
            Console.WriteLine("Total: " + order.Total.ToString("F", CultureInfo.InvariantCulture));
            Console.WriteLine("Date: " + order.Date);
            Console.WriteLine();
        }
    }

    static void Main(string[] args)
    {

        menu.Add(new MenuItem("Cheese Burger", "Klasyczny burger wołowy z serem, sałatą, pomidorem i cebulą.", 15.99, 1));
        menu.Add(new MenuItem("Burger Klasyczny", "Klasyczny burger wołowy z sałatą, pomidorem i cebulą.", 17.99, 1));
        menu.Add(new MenuItem("Bacon Burger", "Klasyczny burger wołowy z bekonem, serem, sałatą, pomidorem i cebulą.", 13.99, 1));
        menu.Add(new MenuItem("Pizza Margherita", "Sos pomidorowy, ser mozzarella, bazylia.", 12.99, 1));
        menu.Add(new MenuItem("Pizza Pepperoni", "Sos pomidorowy, ser mozzarella, pepperoni, bazylia.", 14.99, 1));
        menu.Add(new MenuItem("Pizza Kurczak BBQ", "sos BBQ, ser mozzarella, kurczak, czerwona cebula.", 16.99, 1));
        menu.Add(new MenuItem("Coke", "330 ml", 2.99, 1));
        menu.Add(new MenuItem("Sprite", "330 ml", 4.99, 1));
        menu.Add(new MenuItem("Fanta", "330 ml", 5.99, 1));

        while (true)
        {
            Console.WriteLine("╔════════════════════════════╗\r\n╠  Restaurant Family Diner   ╣\r\n╠════════════════════════════╣");
            Console.WriteLine("║1. Pokaż menu               ║");
            Console.WriteLine("╠════════════════════════════╣");
            Console.WriteLine("║2. Zamów jedzenie           ║");
            Console.WriteLine("╠════════════════════════════╣");
            Console.WriteLine("║3. Zobacz bieżące zamówienie║");
            Console.WriteLine("╠════════════════════════════╣");
            Console.WriteLine("║4. Dodaj do zamówienia      ║");
            Console.WriteLine("╠════════════════════════════╣");
            Console.WriteLine("║5. Usuń z zamówienia        ║");
            Console.WriteLine("╠════════════════════════════╣");
            Console.WriteLine("║6. Potwierdź zamówienie     ║");
            Console.WriteLine("╠════════════════════════════╣");
            Console.WriteLine("║7. Anuluj zamówienie        ║");
            Console.WriteLine("╠════════════════════════════╣");
            Console.WriteLine("║8. Historia                 ║");
            Console.WriteLine("╚════════════════════════════╝");

            int choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    ViewMenu();
                    break;
                case 2:
                    OrderDishes();
                    break;
                case 3:
                    ViewOrder();
                    break;
                case 4:
                    AddDish();
                    break;
                case 5:
                    RemoveDish();
                    break;
                case 6:
                    ConfirmOrder();
                    
                    break;

                case 7:
                    Exit();
                    break;
                case 8:
                    ViewOrderHistory();
                    break;
                default:
                    Console.WriteLine("Nieprawidłowa opcja. Spróbuj ponownie.");
                    break;
            }
        }
    }

    static void ViewMenu()
    {
        Console.WriteLine("Nasze menu:");
        foreach (var item in menu)
        {
            Console.WriteLine($"{item.Name} - {item.Description} - {item.Price} PLN");
        }
    }

    static void OrderDishes()
    {
        Console.WriteLine("Wybierz dania, które chcesz zamówić:");
        for (int i = 0; i < menu.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {menu[i].Name} - {menu[i].Price} PLN");
        }

        while (true)
        {
            int choice = int.Parse(Console.ReadLine());
            if (choice < 1 || choice > menu.Count)
            {
                Console.WriteLine("Nieprawidłowa opcja. Spróbuj ponownie.");
                continue;
            }

            order.Add(menu[choice - 1]);
            Console.WriteLine($"{menu[choice - 1].Name} dodane do zamówienia.");

            Console.WriteLine("Czy chcesz zamówić więcej dań? (t/n)");
            string more = Console.ReadLine();
            if (more != "t")
            {
                break;
            }
        }

    }

    static void ViewOrder()
    {
        if (order.Count == 0)
        {
            Console.WriteLine("Brak pozycji w zamówieniu.");
            return;
        }

        Console.WriteLine("Twoje bieżące zamówienie:");
        foreach (var item in order)
        {
            Console.WriteLine($"{item.Name} - {item.Price} PLN");
        }
    }
    static void ViewOrderHistory()
    {
        try
        {
            string[] lines = File.ReadAllLines("Orders.txt");
            Console.WriteLine("Historia zamówień:");
            foreach (string line in lines)
            {
                Console.WriteLine(line);
            }
        }
        catch (FileNotFoundException)
        {
            Console.WriteLine("Nie znaleziono historii zamówień.");
        }
    }

    static void AddDish()
    {
        Console.WriteLine("Wybierz danie, które chcesz dodać:");
        for (int i = 0; i < menu.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {menu[i].Name} - {menu[i].Price} PLN");
        }

        int choice = int.Parse(Console.ReadLine());
        if (choice < 1 || choice > menu.Count)
        {
            Console.WriteLine("Nieprawidłowa opcja. Spróbuj ponownie.");
            return;
        }

        order.Add(menu[choice - 1]);
        Console.WriteLine($"{menu[choice - 1].Name} dodane do zamówienia.");
    }

    static void RemoveDish()
    {
        Console.WriteLine("Wybierz danie, które chcesz usunąć:");
        for (int i = 0; i < order.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {order[i].Name} - {order[i].Price} PLN");
        }

        int choice = int.Parse(Console.ReadLine());
        if (choice < 1 || choice > order.Count)
        {
            Console.WriteLine("Nieprawidłowa opcja. Spróbuj ponownie.");
            return;
        }

        order.RemoveAt(choice - 1);
        Console.WriteLine($"{order[choice - 1].Name} usunięty z zamówienia.");
    }

    static void ConfirmOrder()
    {
        double total = 0;
        string orderString = "Szczegóły zamówienia:\n";
        foreach (MenuItem item in order)
        {
            orderString += $"{item.Name} - {item.Price} PLN - Ilość: {item.Quantity}\n";
            total += item.Price * item.Quantity;
        }
        orderString += $"Całość: {total} PLN\n";
        Console.WriteLine(orderString);
        File.AppendAllText("Orders.txt", orderString);
        
    }
    
    static void Exit()
    {
        Console.WriteLine("Dziękujemy za odwiedzenie naszej restauracji!");
    }
}