﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Restaurant
{
    internal class OrderSaver
    {
        public void Save(List<MenuItem> order)
        {
            string orderText = "Order: ";
            foreach (MenuItem item in order)
            {
                orderText += item.Name + " " + item.Price + " PLN,";
            }
            File.AppendAllText("Orders.txt", orderText + Environment.NewLine);
        }
    }
}
